# USDT Wallet Tracker (Electron Desktop App)

A professional, secure, offline-first Windows desktop application built with **Electron**, **React**, **Vite**, **SQLite**, and **Node.js** for tracking USDT receipts, SafePal transfers, and fiat sales with automatic calculations, Excel exports, and local backups.

---

## Data Privacy & Offline Guarantee
- **100% Local Storage**: All financial records and transactions are stored locally in an encrypted SQLite database on your Windows PC (`%APPDATA%/usdt-wallet-tracker/data/wallet.db`).
- **No Cloud Synchronization**: The application does not connect to any cloud server, third-party database, or telemetry service.
- **Offline Ready**: No internet connection required after installation.

---

## Step-by-Step Installation & Running Guide

### Prerequisites
Ensure you have **Node.js** (v18 or higher recommended) installed on your Windows PC. You can download it from [nodejs.org](https://nodejs.org/).

### 1. Install Dependencies
Open your terminal in the project directory and run:
```bash
npm install
```

### 2. Run in Development Mode
To launch both the Vite development server and the Electron desktop window concurrently:
```bash
npm run electron:dev
```

### 3. Build the Windows .exe Application
To compile the React frontend, bundle the Electron main process, and generate the Windows `.exe` installer (using `electron-builder`), run:
```bash
npm run electron:build
```

Once the build completes successfully, you will find the generated installer and portable `.exe` inside the **`release/`** folder:
- **`USDT Wallet Tracker Setup 1.0.0.exe`** (Standard Windows Installer)
- **`USDT Wallet Tracker 1.0.0.exe`** (Portable standalone executable)

### 4. Install and Run
Double-click the installer `.exe` to install **USDT Wallet Tracker** on your Windows PC. It will open as a native desktop window with local SQLite persistence.

---

## Features
1. **USDT Received**: Track date, time, USDT amount, sender/source, network, TxID, and notes.
2. **SafePal Transfer**: Record date, time, amount, network, network fee, and destination (SafePal).
3. **USDT Sales**: Record date, time, USDT sold, exchange rate (INR), trading fees, GST, TDS, net INR received, and buyer.
4. **Automatic Calculations**: Real-time balance calculations, total INR received, network fees, trading fees, GST, and TDS.
5. **Excel Export**: Export complete ledger reports to Excel (`.xlsx`).
6. **Local Backup & Restore**: Export and import secure JSON database backups.
7. **Secure Lock Screen**: Password-protected access (default PIN: `1008`).
