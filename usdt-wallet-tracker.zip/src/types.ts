export type TransactionType = 'Received' | 'Transfer' | 'Sold';

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  timestamp: string; // ISO string
  sender?: string;
  network?: string;
  txid?: string;
  notes?: string;
  fee?: number; // Network fee for transfer or general fee
  rate?: number; // Selling price per USDT in INR
  totalInr?: number;
  tradingFee?: number;
  gst?: number;
  tds?: number;
  netInr?: number;
  buyer?: string;
  paymentMethod?: string;
  customMethod?: string;
  profitPercentage?: string | number;
}

export interface WalletSettings {
  exchangeRate: number;
  lockPassword?: string;
  [key: string]: any;
}

export type ViewType = 'dashboard' | 'record' | 'history' | 'settings' | 'export';
