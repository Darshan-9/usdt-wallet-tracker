import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  LayoutDashboard, History as HistoryIcon, PlusCircle, Settings as SettingsIcon,
  Download, ArrowDownLeft, ArrowUpRight, Repeat, Search, Calendar, ChevronLeft,
  ChevronRight, Trash2, Wallet, X, Check, AlertTriangle, Send, Lock, Unlock,
  FileSpreadsheet, ShieldCheck, HelpCircle, ChevronDown, Pencil, UserPlus, FileText, Upload,
  Sun, Moon
} from 'lucide-react';

const THEMES = {
  dark: {
    bgPage: '#071327',
    bgCard: '#142034',
    bgCardAlt: '#1f2a3f',
    bgCardAlt2: '#101b30',
    border: '#2a354b',
    borderLight: '#44474c',
    textPrimary: '#d7e2ff',
    textSecondary: '#c4c6cc',
    textMuted: '#8e9196',
    teal: '#4fdbcc',
    tealDark: '#00b1a3',
    tealDeep: '#003732',
    red: '#ffb4ab',
    redDeep: '#93000a',
  },
  light: {
    bgPage: '#f1f5f9',
    bgCard: '#ffffff',
    bgCardAlt: '#e2e8f0',
    bgCardAlt2: '#cbd5e1',
    border: '#cbd5e1',
    borderLight: '#94a3b8',
    textPrimary: '#0f172a',
    textSecondary: '#334155',
    textMuted: '#64748b',
    teal: '#0d9488',
    tealDark: '#0f766e',
    tealDeep: '#ccfbf1',
    red: '#dc2626',
    redDeep: '#7f1d1d',
  }
};

let currentTheme: 'dark' | 'light' = 'dark';
const C = new Proxy({} as typeof THEMES['dark'], {
  get(_target, prop) {
    const t = THEMES[currentTheme] || THEMES.dark;
    return t[prop as keyof typeof t] || THEMES.dark[prop as keyof typeof THEMES['dark']];
  }
});

const NAV_ITEMS = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'record', label: 'Record', icon: PlusCircle },
  { key: 'history', label: 'History', icon: HistoryIcon },
  { key: 'export', label: 'Export & Backup', icon: FileSpreadsheet },
  { key: 'settings', label: 'Settings', icon: SettingsIcon },
];

const NETWORKS = ['TRC20 (Tron)', 'ERC20 (Ethereum)', 'BEP20 (BSC)', 'Internal (SafePal)'];
const PAYMENT_METHODS = ['Bank Transfer (IMPS/UPI)', 'Cash', 'Other'];

function uid() {
  return `id_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

function initials(name: string) {
  return (name || '?').trim().split(/\s+/).slice(0, 2).map((s) => s[0]?.toUpperCase()).join('') || '?';
}

function fmtUSDT(n: any) {
  const v = Number(n) || 0;
  return v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtINR(n: any) {
  const v = Number(n) || 0;
  return `\u20B9${v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtDateTime(iso: string) {
  if (!iso) return '\u2014';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

function toLocalInputValue(iso?: string) {
  const d = iso ? new Date(iso) : new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function csvEscape(val: any) {
  const s = String(val ?? '');
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function inrValueOf(tx: any, settings: any) {
  if (tx.type === 'Sold') return tx.netInr || (tx.amount * tx.rate);
  return tx.amount * settings.exchangeRate;
}

function IconBadge({ type }: { type: string }) {
  const map: Record<string, { icon: any; color: string; bg: string }> = {
    Received: { icon: ArrowDownLeft, color: C.teal, bg: 'rgba(79,219,204,0.12)' },
    Transfer: { icon: ArrowUpRight, color: C.red, bg: 'rgba(255,180,171,0.12)' },
    Sold: { icon: Repeat, color: '#bac8dc', bg: 'rgba(186,200,220,0.12)' },
  };
  const cfg = map[type] || map.Received;
  const Icon = cfg.icon;
  return (
    <div className="flex items-center justify-center rounded-full shrink-0" style={{ width: 36, height: 36, background: cfg.bg, color: cfg.color }}>
      <Icon size={17} />
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const map: Record<string, { color: string; bg: string; border: string }> = {
    Completed: { color: C.teal, bg: 'rgba(79,219,204,0.15)', border: 'rgba(79,219,204,0.3)' },
    Pending: { color: C.textSecondary, bg: C.bgCardAlt, border: 'rgba(142,145,150,0.3)' },
    Processing: { color: '#bac8dc', bg: 'rgba(186,200,220,0.15)', border: 'rgba(186,200,220,0.3)' },
    Failed: { color: C.red, bg: 'rgba(147,0,10,0.2)', border: 'rgba(255,180,171,0.3)' },
  };
  const cfg = map[status] || map.Completed;
  return (
    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold" style={{ color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.border}` }}>
      {status}
    </span>
  );
}

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>{label}</label>
      {children}
      {hint && <p className="text-xs" style={{ color: C.textMuted }}>{hint}</p>}
    </div>
  );
}

const inputStyle = { background: C.bgPage, border: `1px solid ${C.borderLight}`, color: C.textPrimary };

function TextInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={`w-full rounded-xl px-4 py-2.5 text-sm outline-none transition-all focus:ring-1 ${props.className || ''}`}
      style={{ ...inputStyle, ...(props.style || {}) }}
      onFocus={(e) => { e.target.style.borderColor = C.teal; props.onFocus && props.onFocus(e); }}
      onBlur={(e) => { e.target.style.borderColor = C.borderLight; props.onBlur && props.onBlur(e); }}
    />
  );
}

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...props} className="w-full rounded-xl px-4 py-2.5 text-sm outline-none transition-all" style={{ ...inputStyle, colorScheme: 'dark' }}>
      {props.children}
    </select>
  );
}

function ProfileSwitcher({ profiles, activeProfileId, onSwitch, onAdd, onDelete }: any) {
  const [open, setOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const active = profiles.find((p: any) => p.id === activeProfileId) || profiles[0];

  useEffect(() => {
    function onClick(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const submitAdd = () => {
    const name = newName.trim();
    if (!name) return;
    onAdd(name);
    setNewName('');
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl"
        style={{ background: C.bgCardAlt, border: `1px solid ${C.border}` }}
      >
        <div className="flex items-center justify-center rounded-full text-xs font-bold" style={{ width: 26, height: 26, background: C.tealDeep, color: C.teal }}>
          {initials(active?.name)}
        </div>
        <span className="text-sm font-semibold hidden sm:inline" style={{ color: C.textPrimary }}>{active?.name || 'Profile'}</span>
        <ChevronDown size={14} style={{ color: C.textMuted }} />
      </button>

      {open && (
        <div
          className="absolute right-0 mt-2 w-64 rounded-xl overflow-hidden shadow-2xl z-40"
          style={{ background: C.bgCard, border: `1px solid ${C.border}` }}
        >
          <div className="px-3 py-2 text-xs font-bold uppercase tracking-wider" style={{ color: C.textMuted, borderBottom: `1px solid ${C.border}` }}>
            Switch profile
          </div>
          <div className="max-h-56 overflow-y-auto">
            {profiles.map((p: any) => (
              <div key={p.id} className="flex items-center gap-2 px-3 py-2 group" style={{ background: p.id === activeProfileId ? C.bgCardAlt : 'transparent' }}>
                <button
                  onClick={() => { onSwitch(p.id); setOpen(false); }}
                  className="flex items-center gap-2 flex-1 min-w-0 text-left"
                >
                  <div className="flex items-center justify-center rounded-full text-xs font-bold shrink-0" style={{ width: 24, height: 24, background: C.tealDeep, color: C.teal }}>
                    {initials(p.name)}
                  </div>
                  <span className="text-sm font-medium truncate" style={{ color: p.id === activeProfileId ? C.teal : C.textPrimary }}>{p.name}</span>
                </button>
                {profiles.length > 1 && (
                  <button onClick={() => onDelete(p.id)} className="opacity-0 group-hover:opacity-100 p-1 rounded shrink-0" style={{ color: C.red }} aria-label={`Delete ${p.name}`}>
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 p-3" style={{ borderTop: `1px solid ${C.border}` }}>
            <TextInput
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') submitAdd(); }}
              placeholder="New profile name"
              className="text-xs py-2"
            />
            <button onClick={submitAdd} className="p-2 rounded-lg shrink-0" style={{ background: C.teal, color: C.tealDeep }} aria-label="Add profile">
              <UserPlus size={15} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Header({ view, setView, profiles, activeProfileId, onSwitchProfile, onAddProfile, onDeleteProfile, onLock, theme, setTheme }: any) {
  return (
    <div className="flex items-center justify-between px-4 md:px-8 py-3.5 sticky top-0 z-20" style={{ background: C.bgCard, borderBottom: `1px solid ${C.border}` }}>
      <div className="flex items-center gap-2.5">
        <div className="flex items-center justify-center rounded-lg" style={{ width: 34, height: 34, background: C.tealDeep, color: C.teal }}>
          <Wallet size={18} />
        </div>
        <span className="text-base md:text-lg font-bold tracking-tight" style={{ color: C.teal }}>USDT Wallet Tracker</span>
      </div>
      <nav className="hidden lg:flex items-center gap-1 rounded-xl p-1" style={{ background: C.bgPage, border: `1px solid ${C.border}` }}>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = view === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setView(item.key)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors"
              style={{ background: isActive ? C.teal : 'transparent', color: isActive ? C.tealDeep : C.textSecondary }}
            >
              <Icon size={15} />
              {item.label}
            </button>
          );
        })}
      </nav>
      <div className="flex items-center gap-3">
        <ProfileSwitcher
          profiles={profiles}
          activeProfileId={activeProfileId}
          onSwitch={onSwitchProfile}
          onAdd={onAddProfile}
          onDelete={onDeleteProfile}
        />
        <button
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          className="flex items-center justify-center p-2 rounded-xl text-xs font-semibold"
          style={{ background: C.bgCardAlt, border: `1px solid ${C.border}`, color: C.textSecondary }}
          title="Toggle Theme"
        >
          {theme === 'dark' ? <Sun size={16} style={{ color: '#f0b84f' }} /> : <Moon size={16} style={{ color: C.teal }} />}
        </button>
        <button
          onClick={onLock}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold"
          style={{ background: C.bgCardAlt, border: `1px solid ${C.border}`, color: C.textSecondary }}
          title="Lock Wallet"
        >
          <Lock size={14} /> <span className="hidden sm:inline">Lock</span>
        </button>
      </div>
    </div>
  );
}

function BottomNav({ view, setView }: any) {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 flex items-stretch justify-around px-2 py-2" style={{ background: C.bgCard, borderTop: `1px solid ${C.border}` }}>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const isActive = view === item.key;
        return (
          <button key={item.key} onClick={() => setView(item.key)} className="flex flex-col items-center justify-center gap-1 px-2 py-1.5 rounded-lg flex-1" style={{ color: isActive ? C.teal : C.textMuted }}>
            <Icon size={18} />
            <span className="text-[10px] font-semibold">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function Toast({ message }: { message: string }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-20 lg:bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-2xl text-sm font-semibold" style={{ background: C.bgCardAlt, border: `1px solid ${C.teal}`, color: C.textPrimary }}>
      <Check size={16} style={{ color: C.teal }} />
      {message}
    </div>
  );
}

function MetricCard({ label, inr, usdt, accent, icon: Icon }: any) {
  return (
    <div className="rounded-2xl p-4 flex flex-col gap-1" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>{label}</span>
        {Icon && <Icon size={16} style={{ color: accent || C.textMuted }} />}
      </div>
      <span className="text-2xl font-bold font-mono" style={{ color: C.textPrimary }}>{fmtINR(inr)}</span>
      <span className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtUSDT(usdt)} USDT</span>
    </div>
  );
}

function Dashboard({ transactions, settings, setView, setPresetType, profileName, theme, setTheme }: any) {
  const totals = useMemo(() => {
    let received = 0, transferred = 0, sold = 0, soldInr = 0, fees = 0;
    transactions.forEach((tx: any) => {
      if (tx.type === 'Received') received += tx.amount;
      else if (tx.type === 'Transfer') transferred += tx.amount;
      else if (tx.type === 'Sold') {
        sold += tx.amount;
        soldInr += tx.netInr || (tx.amount * tx.rate);
      }
      fees += Number(tx.fee) || 0;
    });
    const balanceUsdt = received - transferred - sold;
    return {
      received, transferred, sold, fees,
      receivedInr: received * settings.exchangeRate,
      transferredInr: transferred * settings.exchangeRate,
      soldInr,
      feesInr: fees * settings.exchangeRate,
      balanceUsdt,
      balanceInr: balanceUsdt * settings.exchangeRate,
    };
  }, [transactions, settings]);

  const recent = transactions.slice(0, 6);

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1200px] mx-auto px-4 md:px-8 py-6 pb-24 lg:pb-10">
      <div className="rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <div>
          <span className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>{profileName}'s balance</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-3xl md:text-4xl font-bold font-mono" style={{ color: C.teal }}>{fmtINR(totals.balanceInr)}</span>
          </div>
          <span className="text-sm font-mono" style={{ color: C.textMuted }}>{fmtUSDT(totals.balanceUsdt)} USDT</span>
        </div>
        <div className="flex gap-3 flex-wrap">
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: C.bgCardAlt, border: `1px solid ${C.border}`, color: C.textPrimary }}
            title="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={16} style={{ color: '#f0b84f' }} /> : <Moon size={16} style={{ color: C.teal }} />}
            <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
          </button>
          <button onClick={() => { setPresetType('Received'); setView('record'); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}>
            <ArrowDownLeft size={16} /> Receive
          </button>
          <button onClick={() => { setPresetType('Transfer'); setView('record'); }} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: 'transparent', border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>
            <Send size={16} /> Send
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard label="Total received" inr={totals.receivedInr} usdt={totals.received} accent={C.teal} icon={ArrowDownLeft} />
        <MetricCard label="SafePal transfer" inr={totals.transferredInr} usdt={totals.transferred} accent={C.red} icon={Send} />
        <MetricCard label="Total sold" inr={totals.soldInr} usdt={totals.sold} accent="#bac8dc" icon={Repeat} />
        <MetricCard label="Total fees paid" inr={totals.feesInr} usdt={totals.fees} accent="#f0b84f" icon={FileText} />
      </div>

      <div className="rounded-2xl overflow-hidden" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${C.border}` }}>
          <h3 className="text-base font-bold" style={{ color: C.textPrimary }}>Recent activity</h3>
          <button onClick={() => setView('history')} className="text-xs font-bold" style={{ color: C.teal }}>View all</button>
        </div>
        {recent.length === 0 ? (
          <div className="py-14 text-center text-sm" style={{ color: C.textMuted }}>No transactions recorded yet. Add your first record to get started.</div>
        ) : (
          <div>
            {recent.map((tx: any) => (
              <div key={tx.id} className="flex items-center gap-3 px-5 py-3.5" style={{ borderBottom: `1px solid ${C.border}` }}>
                <IconBadge type={tx.type} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold" style={{ color: C.textPrimary }}>{tx.type}</div>
                  <div className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtDateTime(tx.timestamp)}</div>
                  {tx.description && <div className="text-xs truncate mt-0.5" style={{ color: C.textSecondary }}>{tx.description}</div>}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-sm font-mono font-bold" style={{ color: tx.type === 'Received' ? C.teal : C.textPrimary }}>
                    {tx.type === 'Received' ? '+ ' : '- '}{fmtINR(inrValueOf(tx, settings))}
                  </span>
                  <span className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtUSDT(tx.amount)} USDT</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function HistoryView({ transactions, onDelete, onEdit, settings, profileName, setView }: any) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('All');
  const [dateFilter, setDateFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  const filtered = useMemo(() => {
    return transactions.filter((tx: any) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch = !q || (tx.txid && tx.txid.toLowerCase().includes(q)) || (tx.counterparty && tx.counterparty.toLowerCase().includes(q)) || (tx.description && tx.description.toLowerCase().includes(q)) || (tx.buyer && tx.buyer.toLowerCase().includes(q));
      const matchesType = selectedType === 'All' || tx.type === selectedType;
      const matchesDate = !dateFilter || tx.timestamp.startsWith(dateFilter);
      return matchesSearch && matchesType && matchesDate;
    });
  }, [transactions, searchQuery, selectedType, dateFilter]);

  const totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
  const page = Math.min(currentPage, totalPages);
  const paginated = filtered.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1200px] mx-auto px-4 md:px-8 py-6 pb-24 lg:pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: C.textPrimary }}>Transaction history</h2>
          <p className="text-sm mt-1" style={{ color: C.textSecondary }}>Every USDT record for {profileName}, stored locally.</p>
        </div>
        <button
          onClick={() => setView('export')}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold shadow-sm self-start md:self-auto"
          style={{ background: C.bgCardAlt, border: `1px solid ${C.borderLight}`, color: C.textPrimary }}
        >
          <Download size={16} /> Export Options
        </button>
      </div>

      <div className="rounded-2xl p-4 flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between shadow-xl" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <div className="flex flex-col sm:flex-row gap-4 flex-1">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2" style={{ color: C.textMuted }} />
            <TextInput value={searchQuery} onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }} placeholder="Search TXID, buyer or counterparty..." className="pl-10" />
          </div>
          <div className="relative sm:w-56">
            <Calendar size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 z-10 pointer-events-none" style={{ color: C.textMuted }} />
            <TextInput type="date" value={dateFilter} onChange={(e) => { setDateFilter(e.target.value); setCurrentPage(1); }} className="pl-10" style={{ colorScheme: 'dark' }} />
          </div>
        </div>
        <div className="flex rounded-xl p-1 gap-1 overflow-x-auto shrink-0" style={{ background: C.bgPage, border: `1px solid ${C.borderLight}` }}>
          {['All', 'Received', 'Transfer', 'Sold'].map((type) => (
            <button key={type} onClick={() => { setSelectedType(type); setCurrentPage(1); }} className="px-4 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all" style={{ background: selectedType === type ? C.teal : 'transparent', color: selectedType === type ? C.tealDeep : C.textSecondary }}>
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl overflow-hidden flex flex-col shadow-2xl" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[960px]">
            <thead>
              <tr style={{ background: C.bgCardAlt, borderBottom: `1px solid ${C.border}` }}>
                {['Date & time', 'Type', 'Amount (USDT)', 'INR value', 'Counterparty / Buyer', 'Status', ''].map((h, i) => (
                  <th key={h + i} className={`py-3.5 px-5 text-xs font-bold uppercase tracking-wider ${i === 2 || i === 3 ? 'text-right' : ''}`} style={{ color: C.textSecondary }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.length === 0 ? (
                <tr><td colSpan={7} className="py-12 text-center text-sm" style={{ color: C.textMuted }}>No transactions found matching your filters.</td></tr>
              ) : (
                paginated.map((tx: any) => {
                  const isReceive = tx.type === 'Received';
                  return (
                    <tr key={tx.id} className="group" style={{ borderBottom: `1px solid ${C.border}` }}>
                      <td className="py-4 px-5 font-mono text-xs" style={{ color: C.textSecondary }}>{fmtDateTime(tx.timestamp)}</td>
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-2">
                          <IconBadge type={tx.type} />
                          <span className="font-semibold text-sm" style={{ color: C.textPrimary }}>{tx.type}</span>
                        </div>
                      </td>
                      <td className="py-4 px-5 font-mono font-bold text-right text-sm">
                        <span style={{ color: isReceive ? C.teal : C.textPrimary }}>{isReceive ? '+ ' : '- '}{fmtUSDT(tx.amount)}</span>
                      </td>
                      <td className="py-4 px-5 font-mono text-right text-sm" style={{ color: C.textSecondary }}>{fmtINR(inrValueOf(tx, settings))}</td>
                      <td className="py-4 px-5 text-xs" style={{ color: C.textMuted }}>
                        <div>{tx.counterparty || tx.buyer || '\u2014'}</div>
                        {tx.paymentMethod && <div className="mt-0.5 font-semibold" style={{ color: C.teal }}>{tx.paymentMethod}</div>}
                        {tx.description && <div className="mt-0.5" style={{ color: C.textSecondary }}>{tx.description}</div>}
                      </td>
                      <td className="py-4 px-5"><StatusPill status={tx.status} /></td>
                      <td className="py-4 px-5">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => onEdit(tx)} className="p-1.5 rounded-lg" style={{ color: C.teal }} aria-label="Edit transaction"><Pencil size={15} /></button>
                          <button onClick={() => onDelete(tx.id)} className="p-1.5 rounded-lg" style={{ color: C.red }} aria-label="Delete transaction"><Trash2 size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="md:hidden flex flex-col">
          {paginated.length === 0 ? (
            <div className="py-12 text-center text-sm" style={{ color: C.textMuted }}>No transactions found.</div>
          ) : (
            paginated.map((tx: any) => {
              const isReceive = tx.type === 'Received';
              return (
                <div key={tx.id} className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: `1px solid ${C.border}` }}>
                  <IconBadge type={tx.type} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold" style={{ color: C.textPrimary }}>{tx.type}</div>
                    <div className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtDateTime(tx.timestamp)}</div>
                    {tx.description && <div className="text-xs truncate mt-0.5" style={{ color: C.textSecondary }}>{tx.description}</div>}
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span className="text-sm font-mono font-bold" style={{ color: isReceive ? C.teal : C.textPrimary }}>{isReceive ? '+ ' : '- '}{fmtINR(inrValueOf(tx, settings))}</span>
                    <span className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtUSDT(tx.amount)} USDT</span>
                  </div>
                  <div className="flex flex-col gap-1 ml-1">
                    <button onClick={() => onEdit(tx)} className="p-1.5 rounded-lg" style={{ color: C.teal }} aria-label="Edit transaction"><Pencil size={14} /></button>
                    <button onClick={() => onDelete(tx.id)} className="p-1.5 rounded-lg" style={{ color: C.red }} aria-label="Delete transaction"><Trash2 size={14} /></button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="px-5 py-4 flex items-center justify-between text-xs" style={{ background: C.bgCardAlt2, borderTop: `1px solid ${C.border}`, color: C.textSecondary }}>
          <span>Showing {filtered.length === 0 ? 0 : (page - 1) * itemsPerPage + 1}{'\u2013'}{Math.min(page * itemsPerPage, filtered.length)} of {filtered.length}</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))} disabled={page === 1} className="p-1.5 rounded-lg disabled:opacity-40" style={{ background: C.bgCardAlt, color: C.textPrimary }}><ChevronLeft size={16} /></button>
            <span className="px-2 font-mono">Page {page} of {totalPages}</span>
            <button onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))} disabled={page === totalPages} className="p-1.5 rounded-lg disabled:opacity-40" style={{ background: C.bgCardAlt, color: C.textPrimary }}><ChevronRight size={16} /></button>
          </div>
        </div>
      </div>
    </div>
  );
}

function RecordView({ addTransaction, updateTransaction, settings, presetType, showToast, editingTx, clearEditingTx }: any) {
  const isEditing = !!editingTx;
  const [activeTab, setActiveTab] = useState((editingTx && editingTx.type) || presetType || 'Received');

  const blankReceive = () => ({ entries: [{ amount: '', description: '' }], datetime: toLocalInputValue(), network: NETWORKS[0], fee: '', source: '', txid: '', profitPercentage: '0' });
  const blankTransfer = () => ({ datetime: toLocalInputValue(), recipient: '', amount: '', feePercent: settings.transferFeePercent });
  const blankSell = () => ({
    amount: '', rate: settings.exchangeRate, buyer: '', datetime: toLocalInputValue(),
    method: PAYMENT_METHODS[0], customMethod: '', tradingFee: '0', profitPercentage: '0'
  });

  const [receive, setReceive] = useState(blankReceive);
  const [transfer, setTransfer] = useState(blankTransfer);
  const [sell, setSell] = useState(blankSell);

  useEffect(() => {
    if (presetType && !editingTx) setActiveTab(presetType);
  }, [presetType, editingTx]);

  useEffect(() => {
    if (!editingTx) return;
    setActiveTab(editingTx.type);
    if (editingTx.type === 'Received') {
      setReceive({
        entries: [{ amount: String(editingTx.amount ?? ''), description: editingTx.description || '' }],
        datetime: toLocalInputValue(editingTx.timestamp),
        network: editingTx.network || NETWORKS[0], fee: editingTx.fee ? String(editingTx.fee) : '',
        source: editingTx.counterparty || '', txid: editingTx.txid || '',
        profitPercentage: String(editingTx.profitPercentage ?? '0'),
      });
    } else if (editingTx.type === 'Transfer') {
      const feePercent = editingTx.amount ? ((editingTx.fee || 0) / editingTx.amount) * 100 : settings.transferFeePercent;
      setTransfer({
        datetime: toLocalInputValue(editingTx.timestamp), recipient: editingTx.counterparty || '',
        amount: String(editingTx.amount ?? ''), feePercent: Number(feePercent.toFixed(2)),
      });
    } else if (editingTx.type === 'Sold') {
      const knownMethod = PAYMENT_METHODS.includes(editingTx.paymentMethod);
      setSell({
        amount: String(editingTx.amount ?? ''), rate: editingTx.rate ?? settings.exchangeRate,
        buyer: editingTx.counterparty || editingTx.buyer || '', datetime: toLocalInputValue(editingTx.timestamp),
        method: editingTx.paymentMethod ? (knownMethod ? editingTx.paymentMethod : 'Other') : PAYMENT_METHODS[0],
        customMethod: editingTx.paymentMethod && !knownMethod ? editingTx.paymentMethod : '',
        tradingFee: String(editingTx.tradingFee ?? '0'),
        profitPercentage: String(editingTx.profitPercentage ?? '0'),
      });
    }
  }, [editingTx]);

  const receiveTotalAmount = receive.entries.reduce((sum: number, en: any) => sum + (Number(en.amount) || 0), 0);
  const receiveNet = receiveTotalAmount - (Number(receive.fee) || 0);
  const transferFeeAmt = (Number(transfer.amount) || 0) * ((Number(transfer.feePercent) || 0) / 100);
  const transferNetSent = (Number(transfer.amount) || 0) - transferFeeAmt;
  
  const sellAmt = Number(sell.amount) || 0;
  const sellRt = Number(sell.rate) || 0;
  const totalInr = sellAmt * sellRt;
  const tradingFeeInr = Number(sell.tradingFee) || 0;
  const netInr = totalInr - tradingFeeInr;

  const tabs = [
    { key: 'Received', label: 'Receive USDT', icon: ArrowDownLeft },
    { key: 'Transfer', label: 'Wallet transfer', icon: Send },
    { key: 'Sold', label: 'Sell USDT', icon: Repeat },
  ];
  const visibleTabs = isEditing ? tabs.filter((t) => t.key === editingTx.type) : tabs;

  const resetAll = () => {
    setReceive(blankReceive());
    setTransfer(blankTransfer());
    setSell(blankSell());
  };

  const cancelEdit = () => {
    clearEditingTx();
    resetAll();
  };

  const addReceiveEntry = () => setReceive((r) => ({ ...r, entries: [...r.entries, { amount: '', description: '' }] }));
  const removeReceiveEntry = (idx: number) => setReceive((r) => ({ ...r, entries: r.entries.filter((_, i) => i !== idx) }));
  const updateReceiveEntry = (idx: number, field: string, value: string) => setReceive((r) => ({ ...r, entries: r.entries.map((en, i) => (i === idx ? { ...en, [field]: value } : en)) }));

  const commitReceive = () => {
    const validEntries = receive.entries.filter((en) => Number(en.amount) > 0);
    if (validEntries.length === 0) return;
    const totalAmount = validEntries.reduce((sum, en) => sum + Number(en.amount), 0);
    const totalFee = Number(receive.fee) || 0;
    const timestamp = new Date(receive.datetime).toISOString();

    if (isEditing) {
      const entry = validEntries[0];
      const fields = {
        type: 'Received', amount: Number(entry.amount), description: entry.description, timestamp,
        network: receive.network, fee: totalFee, counterparty: receive.source, txid: receive.txid,
        profitPercentage: Number(receive.profitPercentage) || 0,
      };
      updateTransaction({ ...editingTx, ...fields });
      showToast('Deposit updated');
      clearEditingTx();
    } else {
      validEntries.forEach((entry) => {
        const share = totalAmount > 0 ? Number(entry.amount) / totalAmount : 0;
        addTransaction({
          id: uid(), status: 'Completed', type: 'Received', amount: Number(entry.amount), description: entry.description,
          timestamp, network: receive.network, fee: Number((totalFee * share).toFixed(8)),
          counterparty: receive.source, txid: receive.txid,
          profitPercentage: Number(receive.profitPercentage) || 0,
        });
      });
      showToast(validEntries.length > 1 ? `${validEntries.length} deposits recorded` : 'Deposit recorded');
    }
    resetAll();
  };

  const commitTransfer = () => {
    if (!transfer.amount || Number(transfer.amount) <= 0 || !transfer.recipient) return;
    const fields = {
      type: 'Transfer', amount: Number(transfer.amount), timestamp: new Date(transfer.datetime).toISOString(),
      network: 'Internal (SafePal)', fee: transferFeeAmt, counterparty: transfer.recipient,
    };
    if (isEditing) { updateTransaction({ ...editingTx, ...fields }); showToast('Transfer updated'); clearEditingTx(); }
    else { addTransaction({ id: uid(), status: 'Completed', ...fields }); showToast('Transfer recorded'); }
    resetAll();
  };

  const commitSell = () => {
    if (!sell.amount || Number(sell.amount) <= 0 || !sell.rate) return;
    const resolvedMethod = sell.method === 'Other' ? (sell.customMethod.trim() || 'Other') : sell.method;
    const fields = {
      type: 'Sold', amount: sellAmt, timestamp: new Date(sell.datetime).toISOString(),
      rate: sellRt, buyer: sell.buyer, paymentMethod: resolvedMethod,
      totalInr, tradingFee: tradingFeeInr, netInr,
      profitPercentage: sell.profitPercentage
    };
    if (isEditing) { updateTransaction({ ...editingTx, ...fields }); showToast('Sale updated'); clearEditingTx(); }
    else { addTransaction({ id: uid(), status: 'Completed', ...fields }); showToast('Sale recorded'); }
    resetAll();
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1000px] mx-auto px-4 md:px-8 py-6 pb-24 lg:pb-10">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: C.textPrimary }}>{isEditing ? 'Edit transaction' : 'Record transaction'}</h2>
          <p className="text-sm mt-1" style={{ color: C.textSecondary }}>{isEditing ? 'Update the details of this record.' : 'Log a new USDT deposit, transfer, or sale.'}</p>
        </div>
        {isEditing && (
          <button onClick={cancelEdit} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold" style={{ border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>
            <X size={15} /> Cancel edit
          </button>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex md:flex-col gap-1.5 md:w-56 shrink-0 overflow-x-auto">
          {visibleTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button key={tab.key} onClick={() => !isEditing && setActiveTab(tab.key)} className="flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-semibold whitespace-nowrap transition-all" style={{ background: isActive ? C.bgCardAlt : 'transparent', color: isActive ? C.teal : C.textSecondary, border: isActive ? `1px solid ${C.teal}` : '1px solid transparent' }}>
                <Icon size={16} /> {tab.label}
              </button>
            );
          })}
        </div>

        <div className="flex-1 rounded-2xl p-5 md:p-6" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
          {activeTab === 'Received' && (
            <div className="flex flex-col gap-5">
              <div>
                <h3 className="text-lg font-bold" style={{ color: C.textPrimary }}>{isEditing ? 'Edit deposit' : 'Record deposit'}</h3>
                <p className="text-sm" style={{ color: C.textSecondary }}>Log an incoming USDT transaction to your wallet.</p>
              </div>
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>USDT amounts received</label>
                  {!isEditing && (
                    <button type="button" onClick={addReceiveEntry} className="flex items-center gap-1.5 text-xs font-bold" style={{ color: C.teal }}>
                      <PlusCircle size={14} /> Add another amount
                    </button>
                  )}
                </div>
                {receive.entries.map((entry: any, idx: number) => (
                  <div key={idx} className="grid grid-cols-1 sm:grid-cols-[1fr_1.4fr_auto] gap-3 items-end rounded-xl p-3" style={{ background: C.bgPage, border: `1px solid ${C.border}` }}>
                    <div className="flex flex-col gap-1.5">
                      <span className="text-[11px] font-semibold" style={{ color: C.textMuted }}>Amount (USDT)</span>
                      <TextInput type="number" min="0" step="0.01" placeholder="0.00" value={entry.amount} onChange={(e) => updateReceiveEntry(idx, 'amount', e.target.value)} />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <span className="text-[11px] font-semibold" style={{ color: C.textMuted }}>Description</span>
                      <TextInput type="text" placeholder="What's this deposit for?" value={entry.description} onChange={(e) => updateReceiveEntry(idx, 'description', e.target.value)} />
                    </div>
                    {!isEditing && receive.entries.length > 1 && (
                      <button type="button" onClick={() => removeReceiveEntry(idx)} className="p-2.5 rounded-lg justify-self-end" style={{ color: C.red }} aria-label="Remove amount">
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Date & time"><TextInput type="datetime-local" value={receive.datetime} onChange={(e) => setReceive({ ...receive, datetime: e.target.value })} style={{ colorScheme: 'dark' }} /></Field>
                <Field label="Network"><Select value={receive.network} onChange={(e) => setReceive({ ...receive, network: e.target.value })}>{NETWORKS.map((n) => <option key={n} value={n}>{n}</option>)}</Select></Field>
                <Field label="Network fee (optional)" hint="Covers blockchain gas or transfer costs, split across amounts above."><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={receive.fee} onChange={(e) => setReceive({ ...receive, fee: e.target.value })} /></Field>
                <Field label="Source / sender"><TextInput type="text" placeholder="Enter sender address or description" value={receive.source} onChange={(e) => setReceive({ ...receive, source: e.target.value })} /></Field>
                <Field label="TXID (transaction hash)"><TextInput type="text" placeholder="0x..." value={receive.txid} onChange={(e) => setReceive({ ...receive, txid: e.target.value })} /></Field>
                <Field label="Today's profit percentage (%)" hint="Enter today's profit percentage manually"><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={receive.profitPercentage} onChange={(e) => setReceive({ ...receive, profitPercentage: e.target.value })} /></Field>
              </div>
              <div className="rounded-xl px-4 py-3.5 flex items-center justify-between" style={{ background: C.bgPage, border: `1px solid ${C.border}` }}>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>Estimated net deposit</div>
                  <div className="text-xs font-mono" style={{ color: C.textMuted }}>Less network fee</div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold font-mono" style={{ color: C.teal }}>{fmtINR(receiveNet * settings.exchangeRate)}</div>
                  <div className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtUSDT(receiveNet)} USDT</div>
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <button onClick={isEditing ? cancelEdit : resetAll} className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>{isEditing ? 'Cancel' : 'Clear'}</button>
                <button onClick={commitReceive} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}><Check size={16} /> {isEditing ? 'Save changes' : 'Commit record'}</button>
              </div>
            </div>
          )}

          {activeTab === 'Transfer' && (
            <div className="flex flex-col gap-5">
              <div>
                <h3 className="text-lg font-bold" style={{ color: C.textPrimary }}>{isEditing ? 'Edit transfer' : 'Record transfer'}</h3>
                <p className="text-sm" style={{ color: C.textSecondary }}>Log a verified USDT operation to another wallet address.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Date & time"><TextInput type="datetime-local" value={transfer.datetime} onChange={(e) => setTransfer({ ...transfer, datetime: e.target.value })} style={{ colorScheme: 'dark' }} /></Field>
                <Field label="Recipient wallet name"><TextInput type="text" placeholder="Enter recipient name" value={transfer.recipient} onChange={(e) => setTransfer({ ...transfer, recipient: e.target.value })} /></Field>
                <Field label="Amount (USDT)"><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={transfer.amount} onChange={(e) => setTransfer({ ...transfer, amount: e.target.value })} /></Field>
                <Field label="Network fee %"><TextInput type="number" min="0" step="0.01" placeholder="5" value={transfer.feePercent} onChange={(e) => setTransfer({ ...transfer, feePercent: e.target.value })} /></Field>
              </div>
              <div className="rounded-xl px-4 py-3.5 flex items-center justify-between" style={{ background: C.bgPage, border: `1px solid ${C.border}` }}>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>Net amount sent</div>
                  <div className="text-xs font-mono" style={{ color: C.textMuted }}>Amount minus {transfer.feePercent || 0}% fee ({fmtUSDT(transferFeeAmt)} USDT)</div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold font-mono" style={{ color: C.red }}>{fmtINR(transferNetSent * settings.exchangeRate)}</div>
                  <div className="text-xs font-mono" style={{ color: C.textMuted }}>{fmtUSDT(transferNetSent)} USDT</div>
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <button onClick={isEditing ? cancelEdit : resetAll} className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>{isEditing ? 'Cancel' : 'Clear form'}</button>
                <button onClick={commitTransfer} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}><Check size={16} /> {isEditing ? 'Save changes' : 'Confirm transfer'}</button>
              </div>
            </div>
          )}

          {activeTab === 'Sold' && (
            <div className="flex flex-col gap-5">
              <div>
                <h3 className="text-lg font-bold" style={{ color: C.textPrimary }}>{isEditing ? 'Edit sale' : 'USDT sold record'}</h3>
                <p className="text-sm" style={{ color: C.textSecondary }}>Log a USDT sale transaction, trading fee, and net INR value.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="USDT amount sold"><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={sell.amount} onChange={(e) => setSell({ ...sell, amount: e.target.value })} /></Field>
                <Field label="Sale rate (INR per USDT)"><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={sell.rate} onChange={(e) => setSell({ ...sell, rate: e.target.value })} /></Field>
                <Field label="Sold to (buyer name)"><TextInput type="text" placeholder="Enter buyer's name..." value={sell.buyer} onChange={(e) => setSell({ ...sell, buyer: e.target.value })} /></Field>
                <Field label="Date & time"><TextInput type="datetime-local" value={sell.datetime} onChange={(e) => setSell({ ...sell, datetime: e.target.value })} style={{ colorScheme: 'dark' }} /></Field>
                <Field label="Payment received method">
                  <div className="flex flex-col gap-2">
                    <Select value={sell.method} onChange={(e) => setSell({ ...sell, method: e.target.value })}>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{m}</option>)}</Select>
                    {sell.method === 'Other' && (
                      <TextInput type="text" placeholder="Enter payment method" value={sell.customMethod} onChange={(e) => setSell({ ...sell, customMethod: e.target.value })} />
                    )}
                  </div>
                </Field>
                <Field label="Trading fee (INR)"><TextInput type="number" min="0" step="0.01" placeholder="0.00" value={sell.tradingFee} onChange={(e) => setSell({ ...sell, tradingFee: e.target.value })} /></Field>
              </div>
              <div className="rounded-xl px-4 py-3.5 flex flex-col gap-2" style={{ background: C.bgPage, border: `1px solid ${C.border}` }}>
                <div className="flex justify-between items-center text-xs" style={{ color: C.textSecondary }}>
                  <span>Gross total INR:</span>
                  <span className="font-mono">{fmtINR(totalInr)}</span>
                </div>
                {tradingFeeInr > 0 && (
                  <div className="flex justify-between items-center text-xs" style={{ color: C.red }}>
                    <span>Trading Fee:</span>
                    <span className="font-mono">-{fmtINR(tradingFeeInr)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-2" style={{ borderTop: `1px solid ${C.border}` }}>
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textPrimary }}>Net Sale Value (INR)</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold font-mono" style={{ color: C.teal }}>{fmtINR(netInr)}</div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <button onClick={isEditing ? cancelEdit : resetAll} className="px-5 py-2.5 rounded-xl text-sm font-semibold" style={{ border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>{isEditing ? 'Cancel' : 'Cancel'}</button>
                <button onClick={commitSell} className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}><Check size={16} /> {isEditing ? 'Save changes' : 'Commit sale record'}</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ExportView({ transactions, settings, profileName, showToast }: any) {
  const exportCsv = () => {
    const headers = [
      'Date & Time', 'Type', 'Amount (USDT)', 'Fee (USDT)', 'Rate (INR/USDT)',
      'Gross INR', 'Trading Fee (INR)', 'Net INR',
      'Network', 'Counterparty / Buyer', 'Description', 'Payment Method', 'TXID', 'Status'
    ];
    const rows = transactions.map((tx: any) => [
      fmtDateTime(tx.timestamp),
      tx.type,
      tx.amount,
      tx.fee || 0,
      tx.rate || '',
      tx.totalInr || (tx.type === 'Sold' ? tx.amount * tx.rate : tx.amount * settings.exchangeRate),
      tx.tradingFee || 0,
      inrValueOf(tx, settings),
      tx.network || '',
      tx.counterparty || tx.buyer || '',
      tx.description || '',
      tx.paymentMethod || '',
      tx.txid || '',
      tx.status
    ]);
    const csv = [headers, ...rows].map((r) => r.map(csvEscape).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `USDT_Wallet_${(profileName || 'export').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('CSV report downloaded');
  };

  const backupJson = () => {
    const backupData = {
      version: '1.0',
      profile: profileName,
      exportDate: new Date().toISOString(),
      transactions,
      settings
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `USDT_Wallet_Backup_${(profileName || 'wallet').replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('JSON backup downloaded');
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-[800px] mx-auto px-4 md:px-8 py-6 pb-24 lg:pb-10">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: C.textPrimary }}>Export & Backup</h2>
        <p className="text-sm mt-1" style={{ color: C.textSecondary }}>Download your transaction records as CSV or create a complete local backup file.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-2xl p-6 flex flex-col justify-between gap-6" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl" style={{ background: C.tealDeep, color: C.teal }}><FileSpreadsheet size={22} /></div>
              <h3 className="text-lg font-bold" style={{ color: C.textPrimary }}>Spreadsheet CSV</h3>
            </div>
            <p className="text-xs" style={{ color: C.textSecondary }}>Open in Microsoft Excel, Google Sheets, or LibreOffice for accounting and tax filing.</p>
          </div>
          <button onClick={exportCsv} className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}>
            <Download size={16} /> Download CSV Report
          </button>
        </div>

        <div className="rounded-2xl p-6 flex flex-col justify-between gap-6" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-xl" style={{ background: 'rgba(79,219,204,0.15)', color: C.teal }}><FileText size={22} /></div>
              <h3 className="text-lg font-bold" style={{ color: C.textPrimary }}>JSON Backup</h3>
            </div>
            <p className="text-xs" style={{ color: C.textSecondary }}>Save a secure backup file of all transactions and settings to restore later or move to another computer.</p>
          </div>
          <button onClick={backupJson} className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold" style={{ background: C.bgCardAlt, border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>
            <Download size={16} /> Download JSON Backup
          </button>
        </div>
      </div>
    </div>
  );
}

function SettingsView({ settings, updateSettings, onClearAll, transactionCount, showToast, profileName }: any) {
  const [rate, setRate] = useState(settings.exchangeRate);
  const [feePercent, setFeePercent] = useState(settings.transferFeePercent);
  const [fontSize, setFontSize] = useState(settings.fontSize || 12.3);
  const [confirmClear, setConfirmClear] = useState(false);

  const handleFontSizeChange = (val: number) => {
    setFontSize(val);
    document.documentElement.style.fontSize = `${val}px`;
  };

  const save = () => {
    updateSettings({
      exchangeRate: Number(rate) || 0,
      transferFeePercent: Number(feePercent) || 0,
      fontSize: Number(fontSize) || 12.3,
    });
    showToast('Settings saved successfully');
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-[640px] mx-auto px-4 md:px-8 py-6 pb-24 lg:pb-10">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight" style={{ color: C.textPrimary }}>Settings</h2>
        <p className="text-sm mt-1" style={{ color: C.textSecondary }}>Configure default exchange rates, fees, and interface font size.</p>
      </div>

      <div className="rounded-2xl p-6 flex flex-col gap-5" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <Field label="Default exchange rate (INR per USDT)" hint="Used for calculations when no specific rate is set."><TextInput type="number" min="0" step="0.01" value={rate} onChange={(e) => setRate(e.target.value)} /></Field>
        <Field label="Default transfer fee %"><TextInput type="number" min="0" step="0.01" value={feePercent} onChange={(e) => setFeePercent(e.target.value)} /></Field>
        
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold uppercase tracking-wider" style={{ color: C.textSecondary }}>Display Font Size ({fontSize.toFixed(1)}px)</label>
            <div className="flex items-center gap-1.5">
              <button onClick={() => handleFontSizeChange(Math.max(9, fontSize - 1))} className="px-2.5 py-1 rounded-lg text-xs font-bold" style={{ background: C.bgCardAlt, border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>A-</button>
              <button onClick={() => handleFontSizeChange(12.3)} className="px-2.5 py-1 rounded-lg text-xs font-bold" style={{ background: C.bgCardAlt, border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>Reset</button>
              <button onClick={() => handleFontSizeChange(Math.min(18, fontSize + 1))} className="px-2.5 py-1 rounded-lg text-xs font-bold" style={{ background: C.bgCardAlt, border: `1px solid ${C.borderLight}`, color: C.textPrimary }}>A+</button>
            </div>
          </div>
          <input 
            type="range" 
            min="9" 
            max="18" 
            step="0.5" 
            value={fontSize} 
            onChange={(e) => handleFontSizeChange(parseFloat(e.target.value))}
            className="w-full accent-teal-400 cursor-pointer"
          />
          <div className="flex justify-between text-[10px]" style={{ color: C.textMuted }}>
            <span>Smaller (9px)</span>
            <span>Default (12.3px)</span>
            <span>Larger (18px)</span>
          </div>
        </div>

        <button onClick={save} className="self-start flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold" style={{ background: C.teal, color: C.tealDeep }}><Check size={16} /> Save settings</button>
      </div>

      <div className="rounded-2xl p-6 flex flex-col gap-4" style={{ background: C.bgCard, border: `1px solid ${C.redDeep}` }}>
        <div className="flex items-start gap-3">
          <AlertTriangle size={18} style={{ color: C.red }} className="mt-0.5 shrink-0" />
          <div>
            <h3 className="text-sm font-bold" style={{ color: C.textPrimary }}>Clear {profileName}'s data</h3>
            <p className="text-xs mt-1" style={{ color: C.textSecondary }}>Permanently deletes all {transactionCount} recorded transactions for this profile. This cannot be undone.</p>
          </div>
        </div>
        {!confirmClear ? (
          <button onClick={() => setConfirmClear(true)} className="self-start px-4 py-2 rounded-xl text-sm font-semibold" style={{ border: `1px solid ${C.red}`, color: C.red }}>Clear all transactions</button>
        ) : (
          <div className="flex items-center gap-3">
            <button onClick={() => { onClearAll(); setConfirmClear(false); }} className="px-4 py-2 rounded-xl text-sm font-bold" style={{ background: C.red, color: C.redDeep }}>Yes, delete everything</button>
            <button onClick={() => setConfirmClear(false)} className="px-4 py-2 rounded-xl text-sm font-semibold" style={{ color: C.textSecondary }}>Cancel</button>
          </div>
        )}
      </div>
    </div>
  );
}

function LockScreen({ onUnlock, correctPassword }: any) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleNum = (n: string) => {
    if (pin.length < 6) {
      setPin((p) => p + n);
      setError(false);
    }
  };

  const handleClear = () => setPin((p) => p.slice(0, -1));

  const handleEnter = () => {
    if (pin === (correctPassword || '1008')) {
      onUnlock();
    } else {
      setError(true);
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: C.bgPage }}>
      <div className="w-full max-w-sm rounded-3xl p-8 flex flex-col items-center gap-6 shadow-2xl" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
        <div className="flex items-center justify-center rounded-2xl" style={{ width: 64, height: 64, background: C.tealDeep, color: C.teal }}>
          <Lock size={32} />
        </div>
        <div className="text-center">
          <h2 className="text-xl font-bold" style={{ color: C.textPrimary }}>USDT Wallet Locked</h2>
          <p className="text-xs mt-1" style={{ color: C.textSecondary }}>Enter PIN code to unlock</p>
        </div>

        <div className="flex gap-3 justify-center items-center h-12">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="w-4 h-4 rounded-full transition-all"
              style={{
                background: i < pin.length ? C.teal : C.bgCardAlt,
                border: `1px solid ${i < pin.length ? C.teal : C.borderLight}`
              }}
            />
          ))}
        </div>

        {error && <p className="text-xs font-semibold" style={{ color: C.red }}>Incorrect PIN code.</p>}

        <div className="grid grid-cols-3 gap-3 w-full">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((n) => (
            <button
              key={n}
              onClick={() => handleNum(n)}
              className="py-3.5 rounded-2xl text-lg font-bold font-mono transition-colors active:scale-95"
              style={{ background: C.bgCardAlt, color: C.textPrimary, border: `1px solid ${C.border}` }}
            >
              {n}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="py-3.5 rounded-2xl text-xs font-bold transition-colors"
            style={{ background: C.bgCardAlt2, color: C.textSecondary, border: `1px solid ${C.border}` }}
          >
            DEL
          </button>
          <button
            onClick={() => handleNum('0')}
            className="py-3.5 rounded-2xl text-lg font-bold font-mono transition-colors"
            style={{ background: C.bgCardAlt, color: C.textPrimary, border: `1px solid ${C.border}` }}
          >
            0
          </button>
          <button
            onClick={handleEnter}
            className="py-3.5 rounded-2xl text-xs font-bold transition-colors"
            style={{ background: C.teal, color: C.tealDeep }}
          >
            ENTER
          </button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [isLocked, setIsLocked] = useState(true);
  const [view, setView] = useState('dashboard');
  const [profiles, setProfiles] = useState<any[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [settings, setSettings] = useState({ exchangeRate: 90.5, transferFeePercent: 5, lockPassword: '1008', fontSize: 12.3 });
  const [loaded, setLoaded] = useState(false);
  const [presetType, setPresetType] = useState<string | null>(null);
  const [editingTx, setEditingTx] = useState<any | null>(null);
  const [toast, setToast] = useState('');
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      return (localStorage.getItem('theme') as 'dark' | 'light') || 'dark';
    } catch (e) {
      return 'dark';
    }
  });

  useEffect(() => {
    try { localStorage.setItem('theme', theme); } catch (e) {}
  }, [theme]);

  useEffect(() => {
    if (settings.fontSize) {
      document.documentElement.style.fontSize = `${settings.fontSize}px`;
    }
  }, [settings.fontSize]);

  currentTheme = theme;

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2200);
  }, []);

  const loadTransactionsFor = useCallback(async (profileId: string) => {
    try {
      const val = localStorage.getItem(`transactions:${profileId}`);
      if (val) return JSON.parse(val);
    } catch (e) {}
    return [];
  }, []);

  useEffect(() => {
    (async () => {
      let loadedProfiles = [];
      try {
        const pVal = localStorage.getItem('profiles');
        if (pVal) loadedProfiles = JSON.parse(pVal);
      } catch (e) {}

      if (!loadedProfiles || loadedProfiles.length === 0) {
        loadedProfiles = [{ id: uid(), name: 'Main Wallet' }];
        localStorage.setItem('profiles', JSON.stringify(loadedProfiles));
      }
      setProfiles(loadedProfiles);

      let active = localStorage.getItem('activeProfileId');
      if (!active || !loadedProfiles.find((p: any) => p.id === active)) {
        active = loadedProfiles[0].id;
      }
      setActiveProfileId(active);

      try {
        const st = localStorage.getItem('settings');
        if (st) {
          const parsed = JSON.parse(st);
          setSettings({ ...parsed, lockPassword: '1008' });
        }
      } catch (e) {}

      const tx = await loadTransactionsFor(active!);
      setTransactions(tx);
      setLoaded(true);
    })();
  }, [loadTransactionsFor]);

  useEffect(() => {
    if (!loaded) return;
    try { localStorage.setItem('settings', JSON.stringify(settings)); } catch (e) {}
  }, [settings, loaded]);

  const persistTransactions = useCallback((profileId: string, tx: any[]) => {
    try { localStorage.setItem(`transactions:${profileId}`, JSON.stringify(tx)); } catch (e) {}
  }, []);

  const addTransaction = useCallback((tx: any) => {
    setTransactions((prev) => {
      const next = [tx, ...prev].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      persistTransactions(activeProfileId!, next);
      return next;
    });
  }, [activeProfileId, persistTransactions]);

  const updateTransaction = useCallback((tx: any) => {
    setTransactions((prev) => {
      const next = prev.map((t) => (t.id === tx.id ? tx : t)).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      persistTransactions(activeProfileId!, next);
      return next;
    });
  }, [activeProfileId, persistTransactions]);

  const deleteTransaction = useCallback((id: string) => {
    setTransactions((prev) => {
      const next = prev.filter((t) => t.id !== id);
      persistTransactions(activeProfileId!, next);
      return next;
    });
    showToast('Transaction removed');
  }, [activeProfileId, persistTransactions, showToast]);

  const updateSettings = useCallback((next: any) => {
    setSettings((prev) => ({ ...prev, ...next, lockPassword: '1008' }));
  }, []);

  const clearAll = useCallback(() => {
    setTransactions([]);
    persistTransactions(activeProfileId!, []);
    showToast('All transactions cleared');
  }, [activeProfileId, persistTransactions, showToast]);

  const switchProfile = useCallback(async (profileId: string) => {
    if (profileId === activeProfileId) return;
    setActiveProfileId(profileId);
    localStorage.setItem('activeProfileId', profileId);
    const tx = await loadTransactionsFor(profileId);
    setTransactions(tx);
    setEditingTx(null);
    setView('dashboard');
  }, [activeProfileId, loadTransactionsFor]);

  const addProfile = useCallback(async (name: string) => {
    const newProfile = { id: uid(), name };
    setProfiles((prev) => {
      const next = [...prev, newProfile];
      localStorage.setItem('profiles', JSON.stringify(next));
      return next;
    });
    setActiveProfileId(newProfile.id);
    localStorage.setItem('activeProfileId', newProfile.id);
    setTransactions([]);
    setEditingTx(null);
    setView('dashboard');
    showToast(`Profile "${name}" created`);
  }, [showToast]);

  const deleteProfile = useCallback(async (profileId: string) => {
    let remaining = [];
    setProfiles((prev) => {
      remaining = prev.filter((p) => p.id !== profileId);
      localStorage.setItem('profiles', JSON.stringify(remaining));
      return remaining;
    });
    localStorage.removeItem(`transactions:${profileId}`);
    if (profileId === activeProfileId && remaining.length > 0) {
      await switchProfile(remaining[0].id);
    }
    showToast('Profile deleted');
  }, [activeProfileId, switchProfile, showToast]);

  const handleSetView = (v: string) => {
    if (v !== 'record') { setPresetType(null); setEditingTx(null); }
    setView(v);
  };

  const startEdit = useCallback((tx: any) => {
    setEditingTx(tx);
    setView('record');
  }, []);

  const clearEditingTx = useCallback(() => setEditingTx(null), []);

  const activeProfile = profiles.find((p) => p.id === activeProfileId);
  const profileName = activeProfile ? activeProfile.name : 'Wallet';

  if (!loaded) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center" style={{ background: C.bgPage, color: C.textMuted }}>
        Loading wallet{'\u2026'}
      </div>
    );
  }

  if (isLocked) {
    return <LockScreen onUnlock={() => setIsLocked(false)} correctPassword={settings.lockPassword || '1008'} />;
  }

  return (
    <div className="min-h-screen w-full flex flex-col" style={{ background: C.bgPage, fontFamily: 'ui-sans-serif, system-ui, -apple-system, sans-serif' }}>
      <Header
        view={view}
        setView={handleSetView}
        profiles={profiles}
        activeProfileId={activeProfileId}
        onSwitchProfile={switchProfile}
        onAddProfile={addProfile}
        onDeleteProfile={deleteProfile}
        onLock={() => setIsLocked(true)}
        theme={theme}
        setTheme={setTheme}
      />
      <div className="flex-1">
        {view === 'dashboard' && (
          <Dashboard transactions={transactions} settings={settings} setView={setView} setPresetType={setPresetType} profileName={profileName} theme={theme} setTheme={setTheme} />
        )}
        {view === 'history' && (
          <HistoryView transactions={transactions} onDelete={deleteTransaction} onEdit={startEdit} settings={settings} profileName={profileName} setView={setView} />
        )}
        {view === 'record' && (
          <RecordView
            addTransaction={addTransaction}
            updateTransaction={updateTransaction}
            settings={settings}
            presetType={presetType}
            showToast={showToast}
            editingTx={editingTx}
            clearEditingTx={clearEditingTx}
          />
        )}
        {view === 'export' && (
          <ExportView transactions={transactions} settings={settings} profileName={profileName} showToast={showToast} />
        )}
        {view === 'settings' && (
          <SettingsView settings={settings} updateSettings={updateSettings} onClearAll={clearAll} transactionCount={transactions.length} showToast={showToast} profileName={profileName} />
        )}
      </div>
      <BottomNav view={view} setView={handleSetView} />
      <Toast message={toast} />
    </div>
  );
}
