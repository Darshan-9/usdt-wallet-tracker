import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Provide a robust local storage bridge matching window.storage API
if (typeof window !== 'undefined' && !(window as any).storage) {
  (window as any).storage = {
    async get(key: string) {
      const val = localStorage.getItem(key);
      return { value: val };
    },
    async set(key: string, value: string) {
      localStorage.setItem(key, value);
      return { value };
    },
    async delete(key: string) {
      localStorage.removeItem(key);
      return { success: true };
    }
  };
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
