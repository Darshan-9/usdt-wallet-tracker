import express from "express";
import path from "path";
import initSqlJs from "sql.js";
import fs from "fs";
import * as XLSX from "xlsx";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));

const dbDir = path.join(process.cwd(), "data");
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}
const dbPath = path.join(dbDir, "wallet.db");

let db: any = null;

async function initDatabase() {
  const SQL = await initSqlJs();
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      timestamp TEXT NOT NULL,
      sender TEXT,
      network TEXT,
      txid TEXT,
      notes TEXT,
      fee REAL,
      rate REAL,
      totalInr REAL,
      tradingFee REAL,
      gst REAL,
      tds REAL,
      netInr REAL,
      buyer TEXT,
      paymentMethod TEXT,
      customMethod TEXT,
      profitPercentage TEXT
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
  `);

  const exRate = db.exec("SELECT value FROM settings WHERE key = 'exchangeRate'");
  if (exRate.length === 0 || exRate[0].values.length === 0) {
    db.run("INSERT INTO settings (key, value) VALUES ('exchangeRate', '90.5')");
  }

  const pass = db.exec("SELECT value FROM settings WHERE key = 'lockPassword'");
  if (pass.length === 0 || pass[0].values.length === 0) {
    db.run("INSERT INTO settings (key, value) VALUES ('lockPassword', '1008')");
  }

  saveDb();
  console.log("SQLite (sql.js) database initialized successfully at", dbPath);
}

function saveDb() {
  if (db && dbPath) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }
}

// Helper to run query and return objects
function queryAll(sql: string, params: any[] = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows: any[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

function runSql(sql: string, params: any[] = []) {
  db.run(sql, params);
  saveDb();
}

// API Routes
app.get("/api/transactions", (req, res) => {
  try {
    const rows = queryAll("SELECT * FROM transactions ORDER BY timestamp DESC");
    res.json(rows);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/transactions", (req, res) => {
  try {
    const tx = req.body;
    const query = `
      INSERT OR REPLACE INTO transactions (
        id, type, amount, timestamp, sender, network, txid, notes, fee, rate, totalInr, tradingFee, gst, tds, netInr, buyer, paymentMethod, customMethod, profitPercentage
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
      tx.id,
      tx.type,
      tx.amount,
      tx.timestamp,
      tx.sender || null,
      tx.network || null,
      tx.txid || null,
      tx.notes || null,
      tx.fee !== undefined ? tx.fee : null,
      tx.rate !== undefined ? tx.rate : null,
      tx.totalInr !== undefined ? tx.totalInr : null,
      tx.tradingFee !== undefined ? tx.tradingFee : null,
      tx.gst !== undefined ? tx.gst : null,
      tx.tds !== undefined ? tx.tds : null,
      tx.netInr !== undefined ? tx.netInr : null,
      tx.buyer || null,
      tx.paymentMethod || null,
      tx.customMethod || null,
      tx.profitPercentage !== undefined ? String(tx.profitPercentage) : null
    ];
    runSql(query, params);
    res.json({ success: true, id: tx.id });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/api/transactions/:id", (req, res) => {
  try {
    const { id } = req.params;
    runSql("DELETE FROM transactions WHERE id = ?", [id]);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/settings", (req, res) => {
  try {
    const rows = queryAll("SELECT * FROM settings");
    const settingsObj: any = {};
    rows.forEach(r => { settingsObj[r.key] = r.value; });
    res.json(settingsObj);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/settings", (req, res) => {
  try {
    const settings = req.body;
    for (const [key, value] of Object.entries(settings)) {
      db.run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)]);
    }
    saveDb();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/export-excel", (req, res) => {
  try {
    const rows = queryAll("SELECT * FROM transactions ORDER BY timestamp DESC");
    const data = rows.map((tx, idx) => ({
      "S.No": idx + 1,
      "Date & Time": new Date(tx.timestamp).toLocaleString(),
      "Type": tx.type,
      "Amount (USDT)": tx.amount,
      "Network / Method": tx.network || tx.paymentMethod || "-",
      "Sender / Buyer": tx.sender || tx.buyer || "-",
      "Rate (INR)": tx.rate || "-",
      "Total INR": tx.totalInr || "-",
      "Fees (USDT)": tx.fee || 0,
      "Trading Fee (INR)": tx.tradingFee || 0,
      "GST (INR)": tx.gst || 0,
      "TDS (INR)": tx.tds || 0,
      "Net INR": tx.netInr || "-",
      "TxID": tx.txid || "-",
      "Notes": tx.notes || "-"
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "USDT Transactions");

    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "buffer" });
    res.setHeader("Content-Disposition", "attachment; filename=USDT_Wallet_Report.xlsx");
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.send(excelBuffer);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/backup", (req, res) => {
  try {
    const txs = queryAll("SELECT * FROM transactions");
    const sets = queryAll("SELECT * FROM settings");
    res.json({
      version: "1.0",
      exportDate: new Date().toISOString(),
      transactions: txs,
      settings: sets
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/restore", (req, res) => {
  try {
    const { transactions, settings } = req.body;
    db.run("DELETE FROM transactions");
    db.run("DELETE FROM settings");

    if (Array.isArray(transactions)) {
      const stmt = db.prepare(`
        INSERT INTO transactions (id, type, amount, timestamp, sender, network, txid, notes, fee, rate, totalInr, tradingFee, gst, tds, netInr, buyer, paymentMethod, customMethod, profitPercentage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      transactions.forEach(tx => {
        stmt.run([
          tx.id, tx.type, tx.amount, tx.timestamp, tx.sender || null, tx.network || null,
          tx.txid || null, tx.notes || null, tx.fee ?? null, tx.rate ?? null,
          tx.totalInr ?? null, tx.tradingFee ?? null, tx.gst ?? null, tx.tds ?? null,
          tx.netInr ?? null, tx.buyer || null, tx.paymentMethod || null, tx.customMethod || null,
          tx.profitPercentage !== undefined ? String(tx.profitPercentage) : null
        ]);
        stmt.step();
        stmt.reset();
      });
      stmt.free();
    }

    if (Array.isArray(settings)) {
      settings.forEach(s => {
        db.run("INSERT INTO settings (key, value) VALUES (?, ?)", [s.key, s.value]);
      });
    }

    saveDb();
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

async function startServer() {
  await initDatabase();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`USDT Wallet Tracker server running on http://localhost:${PORT}`);
  });
}

startServer();
