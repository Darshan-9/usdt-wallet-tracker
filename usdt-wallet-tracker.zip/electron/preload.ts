import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("electronAPI", {
  getTransactions: () => ipcRenderer.invoke("db:get-transactions"),
  saveTransaction: (tx: any) => ipcRenderer.invoke("db:save-transaction", tx),
  deleteTransaction: (id: string) => ipcRenderer.invoke("db:delete-transaction", id),
  getSettings: () => ipcRenderer.invoke("db:get-settings"),
  saveSettings: (settings: any) => ipcRenderer.invoke("db:save-settings", settings),
  exportExcel: () => ipcRenderer.invoke("db:export-excel"),
  backup: () => ipcRenderer.invoke("db:backup"),
  restore: () => ipcRenderer.invoke("db:restore"),
});
