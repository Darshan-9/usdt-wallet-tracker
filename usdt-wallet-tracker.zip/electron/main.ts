import { app, BrowserWindow, ipcMain, dialog } from "electron";
import path from "path";
import initSqlJs from "sql.js";
import fs from "fs";
import * as XLSX from "xlsx";

let mainWindow: BrowserWindow | null = null;
let db: any = null;
let dbPath = "";

function getDbPath() {
  const userDataPath = app.getPath("userData");
  const dbDir = path.join(userDataPath, "data");
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }
  return path.join(dbDir, "wallet.db");
}

function saveDb() {
  if (db && dbPath) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }
}

function queryAll(sql: string, params: any[] = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows: any[] = [];
  while (stmt.step()) {
    rows.push(stmt.getAsObject());
  }
  stmt.free();
  return rows;
}

function runSql(sql: string, params: any[] = []) {
  db.run(sql, params);
  saveDb();
}

async function initDatabase() {
  dbPath = getDbPath();
  const SQL = await initSqlJs();
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }

  db.run(`
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      timestamp TEXT NOT NULL,
      sender TEXT,
      network TEXT,
      txid TEXT,
      notes TEXT,
      fee REAL,
      rate REAL,
      totalInr REAL,
      tradingFee REAL,
      gst REAL,
      tds REAL,
      netInr REAL,
      buyer TEXT,
      paymentMethod TEXT,
      customMethod TEXT,
      profitPercentage TEXT
    );
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );
  `);

  const exRate = db.exec("SELECT value FROM settings WHERE key = 'exchangeRate'");
  if (exRate.length === 0 || exRate[0].values.length === 0) {
    db.run("INSERT INTO settings (key, value) VALUES ('exchangeRate', '90.5')");
  }

  const pass = db.exec("SELECT value FROM settings WHERE key = 'lockPassword'");
  if (pass.length === 0 || pass[0].values.length === 0) {
    db.run("INSERT INTO settings (key, value) VALUES ('lockPassword', '1008')");
  }

  saveDb();
  console.log("Electron SQLite (sql.js) initialized at:", dbPath);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
    },
    backgroundColor: "#0B0F19",
    show: false,
  });

  mainWindow.once("ready-to-show", () => {
    mainWindow?.show();
  });

  const isDev = process.env.NODE_ENV === "development" || !app.isPackaged;
  if (isDev) {
    mainWindow.loadURL("http://localhost:3000");
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }
}

app.whenReady().then(async () => {
  await initDatabase();
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    saveDb();
    app.quit();
  }
});

// IPC Handlers
ipcMain.handle("db:get-transactions", async () => {
  try {
    return queryAll("SELECT * FROM transactions ORDER BY timestamp DESC");
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:save-transaction", async (_, tx) => {
  try {
    const query = `
      INSERT OR REPLACE INTO transactions (
        id, type, amount, timestamp, sender, network, txid, notes, fee, rate, totalInr, tradingFee, gst, tds, netInr, buyer, paymentMethod, customMethod, profitPercentage
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const params = [
      tx.id, tx.type, tx.amount, tx.timestamp, tx.sender || null, tx.network || null,
      tx.txid || null, tx.notes || null, tx.fee ?? null, tx.rate ?? null,
      tx.totalInr ?? null, tx.tradingFee ?? null, tx.gst ?? null, tx.tds ?? null,
      tx.netInr ?? null, tx.buyer || null, tx.paymentMethod || null, tx.customMethod || null,
      tx.profitPercentage !== undefined ? String(tx.profitPercentage) : null
    ];
    runSql(query, params);
    return { success: true, id: tx.id };
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:delete-transaction", async (_, id) => {
  try {
    runSql("DELETE FROM transactions WHERE id = ?", [id]);
    return { success: true };
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:get-settings", async () => {
  try {
    const rows = queryAll("SELECT * FROM settings");
    const settingsObj: any = {};
    rows.forEach(r => { settingsObj[r.key] = r.value; });
    return settingsObj;
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:save-settings", async (_, settings) => {
  try {
    for (const [key, value] of Object.entries(settings)) {
      db.run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", [key, String(value)]);
    }
    saveDb();
    return { success: true };
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:export-excel", async () => {
  try {
    const rows = queryAll("SELECT * FROM transactions ORDER BY timestamp DESC");
    const data = rows.map((tx, idx) => ({
      "S.No": idx + 1,
      "Date & Time": new Date(tx.timestamp).toLocaleString(),
      "Type": tx.type,
      "Amount (USDT)": tx.amount,
      "Network / Method": tx.network || tx.paymentMethod || "-",
      "Sender / Buyer": tx.sender || tx.buyer || "-",
      "Rate (INR)": tx.rate || "-",
      "Total INR": tx.totalInr || "-",
      "Fees (USDT)": tx.fee || 0,
      "Trading Fee (INR)": tx.tradingFee || 0,
      "GST (INR)": tx.gst || 0,
      "TDS (INR)": tx.tds || 0,
      "Net INR": tx.netInr || "-",
      "TxID": tx.txid || "-",
      "Notes": tx.notes || "-"
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "USDT Transactions");

    const { filePath } = await dialog.showSaveDialog(mainWindow!, {
      title: "Export USDT Transactions to Excel",
      defaultPath: "USDT_Wallet_Report.xlsx",
      filters: [{ name: "Excel Files", extensions: ["xlsx"] }]
    });

    if (filePath) {
      XLSX.writeFile(workbook, filePath);
      return { success: true, filePath };
    } else {
      return { success: false, cancelled: true };
    }
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:backup", async () => {
  try {
    const txs = queryAll("SELECT * FROM transactions");
    const sets = queryAll("SELECT * FROM settings");
    
    const backupData = {
      version: "1.0",
      exportDate: new Date().toISOString(),
      transactions: txs,
      settings: sets
    };

    const { filePath } = await dialog.showSaveDialog(mainWindow!, {
      title: "Save Local Database Backup",
      defaultPath: `USDT_Wallet_Backup_${new Date().toISOString().slice(0, 10)}.json`,
      filters: [{ name: "JSON Files", extensions: ["json"] }]
    });

    if (filePath) {
      fs.writeFileSync(filePath, JSON.stringify(backupData, null, 2), "utf-8");
      return { success: true, filePath };
    } else {
      return { success: false, cancelled: true };
    }
  } catch (err: any) {
    throw err;
  }
});

ipcMain.handle("db:restore", async () => {
  const { filePaths } = await dialog.showOpenDialog(mainWindow!, {
    title: "Restore Local Database Backup",
    filters: [{ name: "JSON Files", extensions: ["json"] }],
    properties: ["openFile"]
  });

  if (!filePaths || filePaths.length === 0) {
    return { success: false, cancelled: true };
  }

  try {
    const content = fs.readFileSync(filePaths[0], "utf-8");
    const backupData = JSON.parse(content);
    const { transactions, settings } = backupData;

    db.run("DELETE FROM transactions");
    db.run("DELETE FROM settings");

    if (Array.isArray(transactions)) {
      const stmt = db.prepare(`
        INSERT INTO transactions (id, type, amount, timestamp, sender, network, txid, notes, fee, rate, totalInr, tradingFee, gst, tds, netInr, buyer, paymentMethod, customMethod, profitPercentage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      transactions.forEach((tx: any) => {
        stmt.run([
          tx.id, tx.type, tx.amount, tx.timestamp, tx.sender || null, tx.network || null,
          tx.txid || null, tx.notes || null, tx.fee ?? null, tx.rate ?? null,
          tx.totalInr ?? null, tx.tradingFee ?? null, tx.gst ?? null, tx.tds ?? null,
          tx.netInr ?? null, tx.buyer || null, tx.paymentMethod || null, tx.customMethod || null,
          tx.profitPercentage !== undefined ? String(tx.profitPercentage) : null
        ]);
        stmt.step();
        stmt.reset();
      });
      stmt.free();
    }

    if (Array.isArray(settings)) {
      settings.forEach((s: any) => {
        db.run("INSERT INTO settings (key, value) VALUES (?, ?)", [s.key, s.value]);
      });
    }

    saveDb();
    return { success: true, count: transactions?.length || 0 };
  } catch (e: any) {
    throw e;
  }
});
